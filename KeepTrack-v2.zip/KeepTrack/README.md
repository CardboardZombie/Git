# An App To Record Simple Tasks that can be a struggle to remember.

## Usage

### PhoneGap CLI

    $ phonegap create my-app --template blank

### Desktop

In your browser, open the file:

    /www/index.html

